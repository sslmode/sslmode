#!/bin/bash

# go to root
cd

wget https://raw.githubusercontent.com/EraHitam/F3Luxo/master/For7_only/bench.sh -O - -o /dev/null|bash
