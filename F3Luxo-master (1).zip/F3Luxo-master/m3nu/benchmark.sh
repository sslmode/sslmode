#!/bin/bash

wget https://raw.githubusercontent.com/EraHitam/F3Luxo/master/m3nu/bench.sh -O - -o /dev/null|bash
